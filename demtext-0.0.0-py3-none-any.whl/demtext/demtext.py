import datetime
import enum
import io
import logging
import pathlib
import re
import sys
from typing import BinaryIO

import pydem.cli
import pydem.format
from pydem import messages


logger = logging.getLogger(__name__)


_SKILL_RE = rb'.*Playing on (?P<skill>\w+) skill'
_TIME_RE = rb'(exact time was|The recorded time was) (?P<time>\S+)'


class _Stat(enum.IntEnum):
    TOTALSECRETS = 11
    TOTALMONSTERS = 12
    SECRETS = 13
    MONSTERS = 14


def _format_time(seconds):
    frac = seconds * 1e5
    seconds = frac // int(1e5)
    frac = frac % int(1e5)

    minutes = seconds // 60
    seconds = seconds % 60

    minutes = int(minutes)
    seconds = int(seconds)
    frac = int(frac)

    if minutes != 0:
        out = f'{minutes}:{seconds:02d}.{frac:05d}'
    elif seconds >= 10:
        out = f'{seconds:02d}.{frac:05d}'
    else:
        out = f'{seconds}.{frac:05d}'

    return out


def _parse_demo_from_file(file: BinaryIO):
    memory_stream = pydem.cli.MemoryBuffer(file.read())
    return pydem.format.Demo.parse(memory_stream)


def _decode_string(in_bytes: bytes) -> str:
    out = io.BytesIO()
    for i in in_bytes:
        if i >= 128:
            i -= 128   # red characters
        if 18 <= i < 28:
            i += 30    # yellow numbers
        out.write(bytes([i]))
    return out.getvalue().decode('ascii')


def demtext(in_dem_file: BinaryIO, demo_date: datetime.date) -> str:
    dem = _parse_demo_from_file(in_dem_file)

    server_info_received = False
    stats = None
    time = None
    finish_time = None
    player_name = None
    joequake_time = None
    skill = None
    print_buf = b""

    out = io.StringIO()

    def print_stats():
        formatted_time = _format_time(finish_time)

        if formatted_time != joequake_time:
            logger.warning('Joequake finish time (%s) does not match finish '
                           'time (%s)',
                          joequake_time, formatted_time)

        print('---------------------------------------------', file=out)
        print(f'Runner  : {player_name}', file=out)
        print()
        print(f'Map     : {map_file} - {map_name}', file=out)
        if skill is not None:
            print(f'Skill   : {skill}', file=out)
        print(f'Kills   : {stats[_Stat.MONSTERS]}/{stats[_Stat.TOTALMONSTERS]}',
              file=out)
        print(f'Secrets : {stats[_Stat.SECRETS]}/{stats[_Stat.TOTALSECRETS]}',
              file=out)
        if finish_time is not None:
            print(f'Time    : {formatted_time}', file=out)
        print(f'Date    : {demo_date.year}-{demo_date.month:02d}-{demo_date.day:02d}',
              file=out)

    for block in dem.blocks:
        for msg in block.messages:
            match msg:
                case messages.ServerInfoMessage():
                    if server_info_received and finish_time is not None:
                        print_stats()

                    stats = {}
                    kills = 0
                    secrets = 0
                    finish_time = None
                    player_name = None
                    joequake_time = None
                    skill = None
                    map_file = _decode_string(
                        msg
                        .models_precache[1]
                        .rsplit(b'/', 1)[1]
                        .split(b'.', 1)[0]
                    )
                    map_name = _decode_string(msg.levelname)
                    logger.info('processing map %s', map_file)

                    server_info_received = True
                case messages.TimeMessage():
                    time = msg.time
                case messages.IntermissionMessage():
                    if finish_time is None:
                        finish_time = time
                case messages.FinaleMessage():
                    if finish_time is None:
                        finish_time = time
                case messages.UpdateStatMessage():
                    stats[msg.stat_id] = msg.stat_value
                case messages.KilledMonsterMessage():
                    stats[_Stat.MONSTERS] += 1
                case messages.FoundSecretMessage():
                    stats[_Stat.SECRETS] += 1
                case messages.UpdateNameMessage():
                    if msg.player_id != 0:
                        raise Exception("Co-op demos not supported")
                    player_name = _decode_string(msg.name)
                case messages.PrintMessage():
                    print_buf += msg.text
                    if b'\n' in print_buf:
                        lines = print_buf.split(b'\n')
                        for line in lines[:-1]:
                            if (m := re.match(_TIME_RE, line)):
                                joequake_time = _decode_string(m.group('time'))
                            if (m := re.match(_SKILL_RE, line)):
                                skill = _decode_string(m.group('skill'))
                        print_buf = lines[-1]

    if finish_time is not None:
        print_stats()
    print('---------------------------------------------', file=out)

    return out.getvalue()


def demtext_main():
    logging.basicConfig(level=logging.INFO)

    if len(sys.argv) < 2:
        print(f"usage: {sys.argv[0]} input-dem", file=sys.stderr)
        raise SystemExit(1)

    in_dem_path = pathlib.Path(sys.argv[1])
    demo_date = datetime.datetime.fromtimestamp(
        in_dem_path.stat().st_ctime
    ).date()
    with in_dem_path.open('rb') as in_dem_file:
        print(demtext(in_dem_file, demo_date))
